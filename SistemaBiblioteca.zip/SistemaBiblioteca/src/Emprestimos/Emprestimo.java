package Emprestimos;
import java.util.ArrayList;
import java.util.List;


public class Emprestimo {
    private String nomeLeitor;
    private String cpfLeitor;
    private String codLivro;
    private String dataEmp;
    
    
    public Emprestimo(String nomeLeitor, String cpfLeitor, String codLivro, String dataEmp) {
        this.nomeLeitor = nomeLeitor;
        this.cpfLeitor = cpfLeitor;
        this.codLivro = codLivro;
        this.dataEmp = dataEmp;
    }

    
    public String getNomeLeitor() {
        return nomeLeitor;
    }
   
    public void setNomeLeitor(String nomeLeitor) {
        this.nomeLeitor = nomeLeitor;
    }

    public String getCpfLeitor() {
        return cpfLeitor;
    }

    public void setCpfLeitor(String cpfLeitor) {
        this.cpfLeitor = cpfLeitor;
    }

    public String getCodLivro() {
        return codLivro;
    }

    public void setCodLivro(String codLivro) {
        this.codLivro = codLivro;
    }
    

    
    public String getDataEmp() {
        return dataEmp;
    }

    
    public void setDataEmp(String dataEmp) {
        this.dataEmp = dataEmp;
    }

    public Emprestimo(String dataEmp) {
        this.dataEmp = dataEmp;
    }
    
   public class listaEmprestimos {
    public static List<Emprestimo> emprestimos = new ArrayList<>();

    }
 @Override
    public String toString(){
        return "Leitor{" + "Nome= " + nomeLeitor + " CPF= " + cpfLeitor + " Código= "
                + codLivro + " Data do Empréstimo= " + dataEmp + " Descrição= " + "}";
    }
}

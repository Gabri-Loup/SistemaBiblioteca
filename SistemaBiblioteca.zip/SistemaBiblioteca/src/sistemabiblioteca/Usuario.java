public class Usuario {
    private Long id;
    private String senha;
    private String login;

    public Usuario(String senha, String login) {
        this.senha = senha;
        this.login = login;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Override
    public String toString() {
        return "Usuario{" + "login=" + login + "senha=" + login + "}";
    }
    
    
    
    
}

package telas;
import Repositorio.Repositorio;
import Livros.Livro;
import Usuario.Leitor;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import Emprestimo.Emprestimos;

public class Emprestimo extends javax.swing.JFrame {

    public Emprestimo() {
        initComponents();
        carregarLivros();
        carregarLeitores();
        carregarCpfLeitores();
    }
    
     public void carregarLivros() {
        for (Livro v : Repositorio.livros) {
            String codLivro = v.getCodigo();
            this.cbCodLivro.addItem(codLivro);
        }
    }
     public void carregarLeitores() {
         for (Leitor l: Repositorio.leitores){
             String nomeLeitor = l.getNome();
             this.cbLeitor.addItem(nomeLeitor);
         }
     }

     public void carregarCpfLeitores(){
     for (Leitor l: Repositorio.leitores){
         String cpfLeitor = l.getCpf();
         this.cbCpf.addItem(cpfLeitor);
     }}
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        cbLeitor = new javax.swing.JComboBox<>();
        cbCodLivro = new javax.swing.JComboBox<>();
        cbCpf = new javax.swing.JComboBox<>();
        tfDataEmp = new javax.swing.JTextField();
        btnEditarEmprestimos = new javax.swing.JButton();

        jFormattedTextField1.setText("jFormattedTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Empréstimo");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Empréstimo");

        jLabel1.setText("Leitor:");

        jLabel3.setText("Código do Livro:");

        jLabel4.setText("Data de Empréstimo:");

        btnSalvar.setText("Salvar");
        btnSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar");
        btnVoltar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        jLabel5.setText("CPF:");

        cbLeitor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbLeitorActionPerformed(evt);
            }
        });

        cbCodLivro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbCodLivroActionPerformed(evt);
            }
        });

        tfDataEmp.setText("22/04/2024");
        tfDataEmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataEmpActionPerformed(evt);
            }
        });

        btnEditarEmprestimos.setText("Editar Emprestimos");
        btnEditarEmprestimos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEditarEmprestimos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarEmprestimosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2)
                            .addComponent(cbLeitor, 0, 132, Short.MAX_VALUE)
                            .addComponent(cbCodLivro, 0, 132, Short.MAX_VALUE)
                            .addComponent(cbCpf, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfDataEmp)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(btnSalvar)
                        .addGap(18, 18, 18)
                        .addComponent(btnVoltar)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditarEmprestimos)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCodLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfDataEmp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cbLeitor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(cbCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar)
                    .addComponent(btnSalvar)
                    .addComponent(btnEditarEmprestimos))
                .addGap(25, 25, 25))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        String codLivro = this.cbCodLivro.getSelectedItem().toString();
        String dataEmp = this.tfDataEmp.getText();
        String leitor = this.cbLeitor.getSelectedItem().toString();
        String cpf = this.cbCpf.getSelectedItem().toString();
        
        Emprestimos novoEmprestimo = new Emprestimos (leitor,cpf,codLivro,dataEmp);
        JOptionPane.showMessageDialog(this, "Empréstimo cadastrado com sucesso!");
        Repositorio.emprestimos.add(novoEmprestimo);
    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void cbLeitorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbLeitorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbLeitorActionPerformed

    private void cbCodLivroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbCodLivroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbCodLivroActionPerformed

    private void tfDataEmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataEmpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDataEmpActionPerformed

    private void btnEditarEmprestimosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarEmprestimosActionPerformed
        new EditarEmprestimos().setVisible(true);
    }//GEN-LAST:event_btnEditarEmprestimosActionPerformed


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Emprestimo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditarEmprestimos;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cbCodLivro;
    private javax.swing.JComboBox<String> cbCpf;
    private javax.swing.JComboBox<String> cbLeitor;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField tfDataEmp;
    // End of variables declaration//GEN-END:variables
}

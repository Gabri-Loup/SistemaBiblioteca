
package telas;

import Devolucoes.Devolucao;
import Livros.Livro;
import Repositorio.Repositorio;
import Usuario.Leitor;


import javax.swing.JOptionPane;

        

public class TelaEditarDevolucoes extends javax.swing.JFrame {
    
    private TelaListarDevolucoes tela;
    private Devolucao devolucao;
    
    
    public TelaEditarDevolucoes (TelaListarDevolucoes tela, Devolucao devolucao ) {
        this.tela = tela;
        this.devolucao = devolucao;
       
        
        initComponents();
        carregarLivros();
        carregarLeitores();
        carregarCpfLeitores();
        mostrarDevoluçoes();
        
    }
    
    public void mostrarDevoluçoes(){
        int indiceNome = 0;
        for( int i = 0; i < Repositorio.leitores.size(); i++){
            if( Repositorio.devolucoes.get(i).getNomeLeitor().equals( devolucao.getNomeLeitor() )){
                indiceNome = i;
            }
         } 
        
        int indiceCPF = 0;
        for( int i = 0; i < Repositorio.leitores.size(); i++){
            if( Repositorio.leitores.get(i).getCpf().equals( devolucao.getNomeLeitor() )){
                indiceCPF = i; 
                
            }
         } 
        
        
        int indiceCodlivro = 0;
        for( int i = 0; i < Repositorio.leitores.size(); i++){
            if( Repositorio.devolucoes.get(i).getCodLivro().equals( devolucao.getCodLivro())){
                indiceCodlivro = i;
            }
         } 
        
        this.tfDataRetorno.setText(devolucao.getDataRetorno());
        this.cbLeitor.setSelectedIndex( indiceNome );
        this.cbCpf.setSelectedIndex(indiceCPF);
        this.cbCodLivro.setSelectedIndex(indiceCodlivro);
    
    }
    
    public void carregarLivros() {
        for (Livro v : Repositorio.livros) {
            String codLivro = v.getCodigo();
            this.cbCodLivro.addItem(codLivro);
        }
       }
        public void carregarLeitores() {
         for (Leitor l: Repositorio.leitores){
             String nomeLeitor = l.getNome();
             this.cbLeitor.addItem(nomeLeitor);
         }   
       }  
        public void carregarCpfLeitores(){
        for (Leitor l: Repositorio.leitores){
         String cpfLeitor = l.getCpf();
         this.cbCpf.addItem(cpfLeitor);
         }
        }
    
        

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        cbLeitor = new javax.swing.JComboBox<>();
        cbCodLivro = new javax.swing.JComboBox<>();
        cbCpf = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfDataRetorno = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();
        btnVoltar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel5.setText("CPF:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setText("Editar Devolução");

        jLabel1.setText("Data de Retorno:");

        jLabel3.setText("Código do Livro:");

        jLabel4.setText("Nome do Leitor:");

        tfDataRetorno.setText("22/04/2024");
        tfDataRetorno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataRetornoActionPerformed(evt);
            }
        });

        btnSalvar.setText("Salvar");
        btnSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar");
        btnVoltar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(cbLeitor, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbCodLivro, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tfDataRetorno, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 198, Short.MAX_VALUE)
                        .addComponent(btnVoltar)))
                .addGap(91, 91, 91))
            .addGroup(layout.createSequentialGroup()
                .addGap(151, 151, 151)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfDataRetorno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbLeitor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbCodLivro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 109, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSalvar)
                            .addComponent(btnVoltar))
                        .addGap(40, 40, 40))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tfDataRetornoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataRetornoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfDataRetornoActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
        String dataRetorno = tfDataRetorno.getText();
        String nomeLeitor = cbLeitor.getSelectedItem().toString();
        String codLivro = cbCodLivro.getSelectedItem().toString();
        String cpfLeitor = cbCpf.getSelectedItem().toString();
                
        this.devolucao.setDataRetorno(dataRetorno);       
        this.devolucao.setNomeLeitor(nomeLeitor);
        this.devolucao.setCodLivro(codLivro);
        this.devolucao.setCpfLeitor(cpfLeitor);
        
        if(dataRetorno.length() < 10 || dataRetorno.length() > 10 ){
            JOptionPane.showMessageDialog(this, "Data inválida");
        }else{
            JOptionPane.showMessageDialog(this, "Devolução alterada com sucesso!");
            this.tela.listarDevolucoes();
            dispose();
        
        }
        
        
        
  
        
        

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    
    
    public static void main(String args[]) {
       
        
      
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cbCodLivro;
    private javax.swing.JComboBox<String> cbCpf;
    private javax.swing.JComboBox<String> cbLeitor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField tfDataRetorno;
    // End of variables declaration//GEN-END:variables
}

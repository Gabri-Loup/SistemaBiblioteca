package Livros;
import java.util.ArrayList;
import java.util.List;


public class Livro {
    private String titulo;
    private String autor;
    private String codigo;
    private String dataPubli;
    private String descricao;

    public Livro(String titulo, String autor, String codigo, String dataPubli, String descricao) {
        this.titulo = titulo;
        this.autor = autor;
        this.codigo = codigo;
        this.dataPubli = dataPubli;
        this.descricao = descricao;
    }
    

    public String getTitulo() {
        return titulo;
    }

  
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

   
    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    
    public String getCodigo() {
        return codigo;
    }

    
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    
    public String getDataPubli() {
        return dataPubli;
    }

    
    public void setDataPubli(String dataPubli) {
        this.dataPubli = dataPubli;
    }

    
    public String getDescricao() {
        return descricao;
    }

    
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
 
   @Override
    public String toString(){
        return "Livro{" + "Titulo=" + titulo + " Autor=" + autor + " Código ="
                + codigo + " Data de Publicação =" + dataPubli + " Descrição =" + descricao + "}";
    }
}

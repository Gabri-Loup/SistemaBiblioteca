package Repositorio;

import java.util.ArrayList;
import java.util.List;
import Usuario.Leitor;
import Livros.Livro;
import Emprestimo.Emprestimos;
import Devolucoes.Devolucao;


public class Repositorio {
    public static List<Livro> livros = new ArrayList<>();
    public static List<Leitor> leitores = new ArrayList<>();
    public static List<Emprestimos> emprestimos = new ArrayList<>();
    public static List<Devolucao> devolucoes = new ArrayList<>();
    
    public static void load() {
        livros.add(new Livro("Harry Potter", "J.K. Rowling", "69503", "02/10/2010", "História sobre um bruxo."));
        livros.add(new Livro("Narnia 1", "C.S. Lewis", "78502", "02/10/2005", "História sobre crianças e um armário mágico."));
        
        leitores.add(new Leitor("Gabriel Bonitão", "R. Vereador Joaquim", "03/02/1998", "Masculino", "70467074129", "gabriellegal@gmail.com"));
        leitores.add(new Leitor("Felipe Sapatão", "R. Banqueiro rico", "12/08/2007", "Masculino", "34167074129", "felipesayajin@gmail.com"));
    
        emprestimos.add(new Emprestimos("Felipe Sapatão", "34167074129", "69503", "21/02/2024"));
        emprestimos.add(new Emprestimos("Gabriel Bonitão", "70467074129", "78502", "22/02/2024"));
        
        devolucoes.add(new Devolucao("28/02/2024", "Gabriel Bonitão", "78502", "70467074129"));
        devolucoes.add(new Devolucao("27/02/2024", "Felipe Sapatão", "69503", "34167074129"));
        
    }
    
    
    
}